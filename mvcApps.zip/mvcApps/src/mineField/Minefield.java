package mineField;

public class Minefield {
}
