package mvc;

public class View {
}
