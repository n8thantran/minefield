package mvc;

public class AppFactory {
}
