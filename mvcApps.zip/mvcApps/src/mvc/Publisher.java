package mvc;

public class Publisher {
}
