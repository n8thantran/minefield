package mvc;

public class Command {
}
