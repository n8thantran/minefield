package mvc;

public class Model {
}
