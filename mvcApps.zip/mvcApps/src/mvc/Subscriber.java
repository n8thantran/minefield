package mvc;

public class Subscriber {
}
